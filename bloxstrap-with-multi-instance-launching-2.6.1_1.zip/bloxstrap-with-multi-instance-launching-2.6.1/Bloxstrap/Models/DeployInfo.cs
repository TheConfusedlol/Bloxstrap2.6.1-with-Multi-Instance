﻿namespace Bloxstrap.Models
{
    public class DeployInfo
    {
        public string Timestamp { get; set; } = null!;
        public string Version { get; set; } = null!;
        public string VersionGuid { get; set; } = null!;
    }
}
