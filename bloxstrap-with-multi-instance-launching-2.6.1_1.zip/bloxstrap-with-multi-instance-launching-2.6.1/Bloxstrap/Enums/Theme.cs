﻿namespace Bloxstrap.Enums
{
    public enum Theme
    {
        Default,
        Light,
        Dark
    }
}
