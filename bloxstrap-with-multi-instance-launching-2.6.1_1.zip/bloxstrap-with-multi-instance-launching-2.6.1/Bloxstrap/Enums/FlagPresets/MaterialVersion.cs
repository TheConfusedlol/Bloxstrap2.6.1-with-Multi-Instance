﻿namespace Bloxstrap.Enums.FlagPresets
{
    public enum MaterialVersion
    {
        Default,
        Old,
        New
    }
}
