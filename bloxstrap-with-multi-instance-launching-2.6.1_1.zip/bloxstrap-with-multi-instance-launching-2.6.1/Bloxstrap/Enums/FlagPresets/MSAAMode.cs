﻿namespace Bloxstrap.Enums.FlagPresets
{
    public enum MSAAMode
    {
        Default,
        x1,
        x2,
        x4,
        x8
    }
}
