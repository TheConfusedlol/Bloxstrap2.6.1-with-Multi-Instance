﻿namespace Bloxstrap.Enums.FlagPresets
{
    public enum RenderingMode
    {
        Default,
        Vulkan,
        D3D11,
        D3D10,
        OpenGL
    }
}
