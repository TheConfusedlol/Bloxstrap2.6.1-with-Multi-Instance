﻿namespace Bloxstrap.Enums.FlagPresets
{
    public enum InGameMenuVersion
    {
        Default,
        V1,
        V2,
        V4
    }
}
